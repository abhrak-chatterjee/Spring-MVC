package com.spring.controller;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

public class LoginBean 
{
	 @NotNull(message="Your username must not be empty")
	 @Size(min=6, max=30, message = "Your username must between 6 and 30 characters") 
	 @Pattern(regexp = "[a-zA-Z]+")
	 private String userName;
	 @NotEmpty
	 //@Size(min = 6, max = 15, message = "Your password must between 6 and 15 characters")
	 @Pattern(regexp = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,15})", message = "Your password must between 6 and 15 characters")
	 private String password;

	 public String getUserName()
	 {
		return userName;
	}

	public void setUserName(String userName)
	{
		this.userName = userName;
	}

	public String getPassword() 
	{
		return password;
	}

	public void setPassword(String password) 
	{
		this.password = password;
	}

}
